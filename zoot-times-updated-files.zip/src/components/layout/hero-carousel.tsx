"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { categories } from "@/lib/products";

export default function HeroCarouselPremium() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActive((current) => (current + 1) % categories.length);
    }, 3000);
    return () => window.clearInterval(timer);
  }, []);

  function showPrevious() {
    setActive((current) => (current - 1 + categories.length) % categories.length);
  }

  function showNext() {
    setActive((current) => (current + 1) % categories.length);
  }

  return (
    <section
      className="relative flex min-h-[700px] items-center overflow-hidden bg-[#100d0b] md:min-h-[760px]"
      aria-label="Featured Zoot Times collections"
    >
      <div className="absolute inset-0">
        {categories.map((category, index) => (
          <div
            key={category.slug}
            aria-hidden="true"
            className={`hero-background-slide absolute inset-y-0 left-[27%] right-0 transition-opacity duration-1000 ease-in-out md:left-[38%] ${
              index === active ? "z-[1] opacity-100" : "opacity-0"
            }`}
          >
            {index === 0 ? (
              <>
                <Image
                  src={category.image}
                  alt=""
                  fill
                  priority
                  sizes="100vw"
                  className="animate-[heroZoom_14s_ease-in-out_infinite_alternate] object-cover object-[72%_center] sm:object-[75%_center] md:hidden"
                />
                <Image
                  src="/images/banners/hero-reference.png"
                  alt=""
                  fill
                  sizes="(max-width: 767px) 1px, 62vw"
                  className="hidden object-cover object-right md:block"
                />
              </>
            ) : (
              <Image
                src={category.image}
                alt=""
                fill
                sizes="100vw"
                className="animate-[heroZoom_14s_ease-in-out_infinite_alternate] object-cover object-[72%_center] sm:object-[75%_center]"
              />
            )}
          </div>
        ))}
        <div className="absolute inset-0 z-[2] bg-gradient-to-r from-[#0d0a08] via-[#0d0a08]/95 via-45% to-[#0d0a08]/15" />
        <div className="absolute inset-0 z-[2] bg-gradient-to-t from-black/70 via-transparent to-black/20" />
        <div className="pointer-events-none absolute inset-0 z-[3] bg-[radial-gradient(ellipse_at_72%_48%,rgba(216,182,106,0.12),transparent_38%)]" />
      </div>

      <div className="container-main relative z-10 w-full py-16 md:py-20">
        <div className="max-w-[660px]">
          <Link href="/" aria-label="Zoot Times home" className="inline-flex items-center gap-4">
            <span className="font-serif text-5xl italic leading-none text-[#e1b45f]">Z</span>
            <span className="text-left">
              <span className="block font-serif text-xl tracking-[3px] text-[#eee6d8] sm:text-2xl">ZOOT TIMES</span>
              <span className="mt-1 block text-[10px] tracking-[1.5px] text-[#c2b9ab] sm:text-xs">Art of the Cozy Lifestyle</span>
            </span>
          </Link>

          <h1 className="mt-12 font-serif text-5xl leading-[1.05] text-[#f5f1eb] sm:text-6xl md:text-7xl xl:text-[86px]">
            Elegance in
            <br />
            Every <span className="italic text-[#e1b45f]">Detail.</span>
          </h1>
          <p className="mt-6 max-w-[500px] text-sm leading-7 text-[#ded7cc] sm:text-base sm:leading-8">
            Discover timeless watches, captivating fragrances
            <br className="hidden sm:block" /> and modern jewelry curated for your everyday lifestyle.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/shop"
              className="group inline-flex min-h-12 items-center justify-center gap-3 rounded-full bg-[#e6ad4d] px-7 text-[11px] font-semibold tracking-[1px] text-[#17120b] transition hover:bg-[#f1c36d]"
            >
              EXPLORE COLLECTION
              <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/about"
              className="inline-flex min-h-12 items-center justify-center rounded-full border border-[#d8b66a] px-7 text-[11px] tracking-[1px] text-[#f1e8da] transition hover:bg-white/10"
            >
              OUR STORY
            </Link>
          </div>

          <nav aria-label="Browse categories" className="mt-10 flex flex-wrap items-center gap-y-3">
            {categories.map((category, index) => (
              <div key={category.slug} className="flex items-center">
                <Link
                  href={`/shop/${category.slug}`}
                  aria-current={index === active ? "true" : undefined}
                  className={`inline-flex items-center gap-3 py-1 pr-5 text-[10px] tracking-[1.5px] transition sm:pr-7 ${
                    index === active ? "text-white" : "text-[#c7beb0] hover:text-white"
                  }`}
                >
                  <span className="text-base text-[#e1b45f]">0{index + 1}</span>
                  {category.shortName.toUpperCase()}
                </Link>
                {index < categories.length - 1 && <span aria-hidden="true" className="mr-5 h-6 border-l border-white/40 sm:mr-7" />}
              </div>
            ))}
          </nav>
        </div>
      </div>

      <div className="absolute bottom-7 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2" aria-label="Hero pagination">
        {categories.map((category, index) => (
          <button
            key={category.slug}
            type="button"
            onClick={() => setActive(index)}
            aria-label={`Show ${category.shortName} hero image`}
            aria-pressed={index === active}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === active ? "w-3 bg-[#e1b45f]" : "w-2 bg-white/50 hover:bg-white"
            }`}
          />
        ))}
      </div>

      <div className="absolute bottom-5 right-5 z-20 flex gap-3 sm:bottom-7 sm:right-8">
        <button
          type="button"
          onClick={showPrevious}
          aria-label="Previous hero image"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/45 bg-black/20 text-white transition hover:border-[#e1b45f] hover:text-[#e1b45f]"
        >
          <ArrowLeft size={17} />
        </button>
        <button
          type="button"
          onClick={showNext}
          aria-label="Next hero image"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/45 bg-black/20 text-white transition hover:border-[#e1b45f] hover:text-[#e1b45f]"
        >
          <ArrowRight size={17} />
        </button>
      </div>
    </section>
  );
}
