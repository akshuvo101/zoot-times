"use client";

import { useState } from "react";
import { ShoppingBag, Check, Minus, Plus } from "lucide-react";

type CartLine = { productId: string; quantity: number };

export default function AddToCart({ productId, stock, disabled }: { productId: string; stock: number; disabled?: boolean }) {
  const [added, setAdded] = useState(false);
  const [quantity, setQuantity] = useState(1);

  function add() {
    const current: CartLine[] = JSON.parse(localStorage.getItem("zoot-cart") || "[]");
    const found = current.find((line) => line.productId === productId);
    if (found) found.quantity += quantity;
    else current.push({ productId, quantity });
    localStorage.setItem("zoot-cart", JSON.stringify(current));
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1600);
  }

  return <div className="flex flex-wrap items-center gap-3">
    <div className="flex h-11 items-center border border-white/15" aria-label="Quantity">
      <button type="button" disabled={disabled || quantity <= 1} onClick={() => setQuantity((value) => value - 1)} aria-label="Decrease quantity" className="px-3 text-[#c5beb1] disabled:opacity-40"><Minus size={14}/></button>
      <span aria-live="polite" className="min-w-7 text-center text-sm">{quantity}</span>
      <button type="button" disabled={disabled || quantity >= stock} onClick={() => setQuantity((value) => value + 1)} aria-label="Increase quantity" className="px-3 text-[#c5beb1] disabled:opacity-40"><Plus size={14}/></button>
    </div>
    <button disabled={disabled} onClick={add} className="gold-button min-h-11 disabled:cursor-not-allowed disabled:opacity-40">
      {added ? <><Check size={16}/> ADDED TO CART</> : <><ShoppingBag size={16}/> ADD TO CART</>}
    </button>
  </div>;
}
