"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { categories } from "@/lib/products";

export default function HeroCarouselPremium() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setActive((current) => (current + 1) % categories.length);
    }, 3000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <section
      className="relative flex min-h-[580px] items-center overflow-hidden bg-[#11100e] md:min-h-[680px]"
      aria-label="Featured Zoot Times collections"
    >
      <div className="absolute inset-0">
        {categories.map((category, index) => {
          const isActive = index === active;
          return (
            <div
              key={category.slug}
              aria-hidden="true"
              className={`hero-background-slide absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                isActive ? "z-[1] opacity-100" : "opacity-0"
              }`}
            >
              <Image
                src={category.image}
                alt=""
                fill
                priority={index === 0}
                sizes="100vw"
                className="animate-[heroZoom_14s_ease-in-out_infinite_alternate] object-cover object-[72%_center] sm:object-[75%_center]"
              />
            </div>
          );
        })}
        <div className="absolute inset-0 z-[2] bg-gradient-to-r from-[#11100e]/95 via-[#11100e]/70 to-[#11100e]/15" />
        <div className="absolute inset-0 z-[2] bg-gradient-to-t from-[#11100e]/70 via-transparent to-[#11100e]/20" />
        <div className="pointer-events-none absolute inset-0 z-[3] bg-[radial-gradient(ellipse_at_center,rgba(17,16,14,0)_0%,rgba(17,16,14,.35)_70%,rgba(17,16,14,.65)_100%)]" />
      </div>

      <div className="container-main relative z-[10] py-24">
        <div className="max-w-[700px]">
          <p className="section-label mb-7">THE ART OF THE COZY LIFESTYLE</p>
          <h1 className="font-serif text-5xl leading-[1.1] sm:text-7xl lg:text-[86px]">
            Elegance in
            <br />
            Every <span className="italic gold-text">Detail.</span>
          </h1>
          <p className="mt-7 max-w-[520px] text-sm leading-8 text-[#e0d9cd] md:text-base">
            Discover timeless watches, captivating fragrances and modern jewelry curated for your everyday lifestyle.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link href="/shop" className="gold-button group flex items-center gap-2">
              <span>EXPLORE COLLECTION</span>
              <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
            <Link href="/about" className="outline-button">OUR STORY</Link>
          </div>
          <div className="mt-12 flex flex-wrap gap-3" role="list" aria-label="Browse categories">
            {categories.map((category, index) => (
              <Link
                key={category.slug}
                href={`/shop/${category.slug}`}
                role="listitem"
                className={`border bg-black/25 px-4 py-3 text-[10px] tracking-[1.5px] text-white backdrop-blur-sm transition ${
                  index === active
                    ? "border-[#d8b66a]/70 text-[#e1c37f]"
                    : "border-white/25 hover:border-[#d8b66a] hover:text-[#e1c37f]"
                }`}
              >
                <span className="mr-2 text-[#d8b66a]">0{index + 1}</span>
                {category.shortName.toUpperCase()}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-5 right-5 z-20 flex gap-2 sm:bottom-8 sm:right-8" aria-label="Hero pagination">
        {categories.map((category, index) => (
          <button
            key={category.slug}
            type="button"
            onClick={() => setActive(index)}
            aria-label={`Show ${category.shortName} hero image`}
            aria-pressed={index === active}
            className={`h-1.5 rounded-sm transition-all duration-300 ${
              index === active ? "w-10 bg-[#d8b66a]" : "w-3 bg-white/50 hover:bg-white"
            } focus:outline-none focus-visible:ring-2 focus-visible:ring-[#d8b66a]/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#11100e]`}
          />
        ))}
      </div>
    </section>
  );
}
